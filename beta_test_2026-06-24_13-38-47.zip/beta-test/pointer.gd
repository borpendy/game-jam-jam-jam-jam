extends Sprite2D
@onready var minigame: Node2D = $".."
var newposy
@onready var pointer: Sprite2D = $"."
var size
var velocity = 0
var acceleration = 0.01
var current = 0
var current_target = 0

var time_passed: float = 0.0
const TIME_INTERVAL: float = 2
var current_smooth = 90

var catchprogress = 1000


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	
	
	size = pointer.get_rect().size * pointer.scale
	
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	#create new current
	time_passed += delta
	if time_passed >= TIME_INTERVAL:
		current_target = randf_range(-0.01,0.01)
	
	current = current + (current_target-current)/current_smooth
		
	if Input.is_action_pressed("left_click"):
		#move bar down
		velocity = velocity + acceleration
		
			
	if Input.is_action_pressed("right_click"):
		#move bar up
		velocity = velocity - acceleration
		
	if minigame.rectposition.has_point(Vector2(position.x, position.y + velocity + size.y/2)) and minigame.rectposition.has_point(Vector2(position.x, position.y + velocity - size.y/2)):
			#if pointer inside bar
			velocity = velocity + current
			position.y = position.y + velocity
	else:
		velocity = current
	
	#make sure sprite is never larger than bar
	if minigame.targetposition.has_point(Vector2(position.x, position.y-size.y/2)) or minigame.targetposition.has_point(Vector2(position.x, position.y+size.y/2)):
		#catch logic
		catchprogress += 5
	else:
		catchprogress -= 1
	
	
	
	pass
