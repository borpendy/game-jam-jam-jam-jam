extends Node2D
@onready var player: CharacterBody2D = %Player

#get scripts
const hook = preload("res://hook.tscn")
var playerx = 0;
var boatposx = 0;
var boatposy = 0;
var hook1


var time_passed: float = 0.0
const TIME_INTERVAL: float = 2
var hooksplaced = 0
var hooksmax = 5

var catchevent = false



# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	
	time_passed += delta
	
	#places hooks where the fish has not been caught
	if time_passed >= TIME_INTERVAL and catchevent == false:
		if (hooksplaced<hooksmax):
			#generates new hook object
			hook1 = hook.instantiate()
			hook1.position.x = player.position.x - randf_range(-500,500)
			hook1.position.y = player.position.y - 600
			hook1.xstart = boatposx;
			hook1.ystart = boatposy;
			add_child(hook1)
			hooksplaced += 1
			time_passed = 0
	
	
	
	
	
	for child in get_children():
		if child is Hook:
			#updates starting location of hook lines
			child.xstart = boatposx;
			child.ystart = boatposy;
			#print(abs(child.position.x-player.position.x))
			#frees hooks when out of range
			if abs(child.position.x-player.position.x)>1200:
				child.queue_free()
		
		if child is Player:
			#gets player position
			playerx = child.position.x
			#print(playerx)
			
		#gets boat position, sets boat velocity
		if child is Boat:
			boatposx = child.position.x
			boatposy = child.position.y
			child.vel = (playerx-child.position.x)/100
