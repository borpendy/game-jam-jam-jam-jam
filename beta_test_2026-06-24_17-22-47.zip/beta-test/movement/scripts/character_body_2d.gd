extends CharacterBody2D
class_name Player

@onready var input_manager = %InputManager
@onready var engine = %PhysicsEngine
@onready var printer = %DebugPrinter
@onready var stats = self.get_node("PlayerStats")
@onready var hitbox: CollisionShape2D = $Hitbox
@onready var animated_sprite_2d: AnimatedSprite2D = $AnimatedSprite2D

var minigame

const fishscene = preload("res://minigame.tscn")
var colliding = false
var mg = false
var onhook = false

var rot = 0
var hookx = 0
var hooky = 0
var reference = 0
var r_reference = 0

var health = 3
var escapes = 0
var status = 0

var currenthook

var actions = {
	"left_clicked": [on_left_click, on_left_click_released],
	"sprint_pressed": [on_sprint_pressed, on_sprint_released]
}

var accel
var max_vel
var min_vel
var mass
var initial_mass
var direction_vector
var friction_coefficient
var drift
var max_stamina
var stamina
var time_since_last_stamina
var stamina_recover_time
var stamina_regen
var using_stamina
var sprint_velboost
var sprint_accelboost
var mass_scale_ratio

func initialise_variables():
	accel = stats.acceleration
	max_vel = stats.max_velocity
	min_vel = stats.min_velocity
	mass = stats.mass
	initial_mass = mass
	friction_coefficient = stats.friction_coefficient
	drift = stats.drift
	stamina = stats.stamina
	max_stamina = stamina
	stamina_recover_time = stats.stamina_recover_time
	stamina_regen = stats.stamina_regen
	time_since_last_stamina = -1
	using_stamina = false
	sprint_velboost = stats.sprint_velboost
	sprint_accelboost = stats.sprint_accelboost
	mass_scale_ratio = stats.mass_scale_ratio
	direction_vector = Vector2(0, 0)
	
func _ready():
	reference = animated_sprite_2d.size
	initialise_variables()
	for action in actions:
		input_manager.get_indexed(action).connect(actions[action][0])

func on_left_click(click_position: Vector2):
	var curr_position = position
	printer.debug_print(name, "Current pos " + str(curr_position))
	if colliding == false:
		rotation = velocity.angle()+PI
		direction_vector = click_position - curr_position
		direction_vector = (direction_vector / (direction_vector.length())) * accel

func on_left_click_released():
	direction_vector = Vector2(0, 0)
	
func on_sprint_pressed():
	printer.debug_print(name, "Current sprinting velocity: " + str(velocity))
	if stamina > 0:
		max_vel = stats.max_velocity * sprint_velboost
		accel = stats.acceleration * sprint_accelboost
		stamina -= 1
		time_since_last_stamina = 0
		using_stamina = true
	else:
		on_sprint_released()
	
func on_sprint_released():
	max_vel = stats.max_velocity
	using_stamina = false
	
func _input(event: InputEvent) -> void:
	for action in actions:
		if event.is_action_released(action):
			actions[action][1].call()

func adjust_stamina():
	if not using_stamina:
		time_since_last_stamina += 1
	if time_since_last_stamina > stamina_recover_time:
		if not stamina + stamina_regen > max_stamina:
			stamina += stamina_regen

func adjust_scale():
	var scalar = 1 + (float(mass - initial_mass)/mass_scale_ratio)
	hitbox.scale = Vector2(scalar, scalar)
	animated_sprite_2d.scale = Vector2(scalar, scalar)
	print(scalar)
func _physics_process(delta: float) -> void:
	# minigame handling
	adjust_stamina()
	adjust_scale()
	
	if colliding == true:
		engine.set_velocity(self,0,stats.max_velocity)
		if mg == false:
			#one shot instantiate minigame
			get_parent().catchevent = true
			mg = true
			minigame = fishscene.instantiate()
			add_child(minigame)
			
			
		if status == 1:
			#escape event - from minigame
			escapes += 1
			mg = false
			colliding = false
			get_parent().catchevent = false
			currenthook.queue_free()
			status = 0
			
		if status == 2:
			#catch event - from minigame
			health -= 1
			mg = false
			colliding = false
			get_parent().catchevent = false
			currenthook.queue_free()
			status = 0
		
		r_reference = reference.rotated(rotation)
		position.x = hookx
		position.y = hooky+r_reference.y/2
		if rotation < PI/2:
			rotation += 0.1
			
			
		if rotation > PI/2 :
			rotation -= 0.1
		
	engine.add_velocity(self, direction_vector, max_vel)
	engine.add_friction(self, friction_coefficient, max_vel)
	move_and_slide()
