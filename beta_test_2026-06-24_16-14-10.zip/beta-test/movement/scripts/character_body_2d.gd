extends CharacterBody2D
class_name Player

@onready var input_manager = %InputManager
@onready var engine = %PhysicsEngine
@onready var printer = %DebugPrinter
@onready var stats = self.get_node("PlayerStats")
@onready var hitbox: CollisionShape2D = $Hitbox
@onready var animated_sprite_2d: AnimatedSprite2D = $AnimatedSprite2D

var minigame

const fishscene = preload("res://minigame.tscn")
var colliding = false
var mg = false
var onhook = false

var rot = 0
var hookx = 0
var hooky = 0
var reference = 0
var r_reference = 0

var health = 3
var escapes = 0
var status = 0

var currenthook
var mass = 50



func _ready():
	reference = animated_sprite_2d.size
	input_manager.left_clicked.connect(on_left_click)

func on_left_click(click_position: Vector2):
	#if not in minigame move fish
	if colliding == false:
		var curr_position = position
		var direction_vector = click_position - curr_position
		direction_vector = (direction_vector / (direction_vector.length())) * stats.acceleration
		rotation = velocity.angle()+PI
		#set sprite flip here
		engine.add_velocity(self, direction_vector, stats.max_velocity)
	
	
func _input(event: InputEvent) -> void:
	pass
	#inputs go here
			
			

func _physics_process(delta: float) -> void:
	# minigame handling
	if colliding == true:
		engine.set_velocity(self,0,stats.max_velocity)
		if mg == false:
			#one shot instantiate minigame
			get_parent().catchevent = true
			mg = true
			minigame = fishscene.instantiate()
			add_child(minigame)
			
			
		if status == 1:
			#escape event - from minigame
			escapes += 1
			mg = false
			colliding = false
			get_parent().catchevent = false
			currenthook.queue_free()
			status = 0
			
		if status == 2:
			#catch event - from minigame
			health -= 1
			mg = false
			colliding = false
			get_parent().catchevent = false
			currenthook.queue_free()
			status = 0
		
		r_reference = reference.rotated(rotation)
		position.x = hookx
		position.y = hooky+r_reference.y/2
		if rotation < PI/2:
			rotation += 0.1
			
			
		if rotation > PI/2 :
			rotation -= 0.1
		
			
	move_and_slide()
