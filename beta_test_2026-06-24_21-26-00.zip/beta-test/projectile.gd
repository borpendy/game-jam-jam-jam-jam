extends Node2D

const projectile = preload("res://projectile.tscn")
var scene
var time
var interval
var enable

func create(scene, interval, enable):
	var new_projectile = projectile.instantiate()
	new_projectile.scene = scene
	new_projectile.time = 0.0
	new_projectile.interval = interval
	new_projectile.enable = enable
	
	return new_projectile
