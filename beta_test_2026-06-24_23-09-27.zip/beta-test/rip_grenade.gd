extends Node2D
class_name RipGrenade
@onready var mine_sprite = $MineSprite
@onready var explosion_sprite = $ExplosionSprite
const current_scene: PackedScene = preload("res://movement/scenes/current.tscn")
var time_passed: float = 0.0
const timer: float = 2
var lifespan = 2
var current
var grenade_state

var rng = RandomNumberGenerator.new()
var velocity_lb = -20
var velocity_ub = 20
var current_scale = Vector2(5, 5)
# Called every frame. 'delta' is the elapsed time since the previous frame.

func _ready():
	current = null
	grenade_state = "charged"
	explosion_sprite.visible = false
	mine_sprite.visible = true

func create_current():
	var new_current = current_scene.instantiate()
	new_current.scale = current_scale
	new_current.position = explosion_sprite.position
	new_current.velocity = Vector2(rng.randf_range(velocity_lb, velocity_ub),rng.randf_range(velocity_lb, velocity_ub))
	new_current.lifespan = lifespan
	add_child(new_current)
	return new_current
	
func _process(delta: float) -> void:
	time_passed += delta
	if grenade_state == "charged":
		position.y += 5*60*(delta/1)
	
	if time_passed>timer:
		if current == null:
			current = create_current()
			explosion_sprite.visible = true
			mine_sprite.visible = false
			explosion_sprite.play() # Currently plays until it frees queue, should probably just end it 
			grenade_state = "current"
	
	if grenade_state == "current":
		if not current:
			queue_free()
		
	pass
