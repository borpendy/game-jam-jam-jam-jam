extends Node2D
@onready var player: CharacterBody2D = %Player
@onready var projectile_loader = $Projectile

#get scripts
const hook = preload("res://hook.tscn")
const bait = preload("res://bait.tscn")
const bomb = preload("res://bomb.tscn")
const stunmine = preload("res://stun_mine.tscn")
const taser = preload("res://taser.tscn")
const rip_grenade = preload("res://rip_grenade.tscn")

var playerx = 0;
var boatposx = 0;
var boatposy = 0;
var hook1
var bait1

var time_passed: float = 0.0


var hook_time = 0.0
const Hook_Interval: float = 2
var hooksplaced = 0
var hooksmax = 5

var catchevent = false

var projectiles # Initialised on _ready
var available_projectiles = {
	bomb: {
		"time": 0.0,
		"interval": 1,
		"enable": false
	},
	stunmine: {
		"time": 1.0,
		"interval": 5,
		"enable": false
	},
	taser: {
		"time": 2.0,
		"interval": 5,
		"enable": false
	},
	rip_grenade: {
		"time": 2.0,
		"interval": 5,
		"enable": true
	},
}

var instantiated_projectiles = {}
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	projectiles = []
	for projectile_scene in available_projectiles:
		projectiles.append(
			projectile_loader.create(
				projectile_scene, 
				available_projectiles[projectile_scene]["time"],
				available_projectiles[projectile_scene]["interval"],
				available_projectiles[projectile_scene]["enable"],
				)
		)	

func manage_projectile(projectile, delta):
	projectile.time += delta
	
	if (projectile.time >= projectile.interval and projectile.enable):
		if instantiated_projectiles.get(projectile):
			instantiated_projectiles[projectile].queue_free()
		var projectile_obj = projectile.scene.instantiate()
		projectile_obj.position.x = boatposx
		projectile_obj.position.y = boatposy
		add_child(projectile_obj)
		instantiated_projectiles[projectile] = projectile_obj
		projectile.time = 0
		
# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	
	hook_time += delta
	
	#places hooks where the fish has not been caught
	if catchevent == false:
		if hook_time >= Hook_Interval:
			if (hooksplaced<hooksmax):
				#generates new hook object
				hook1 = hook.instantiate()
				var xpos = player.position.x - randf_range(-500,500)
				hook1.position.x = xpos
				var ypos = player.position.y - 600
				hook1.position.y = ypos
				hook1.xstart = boatposx;
				hook1.ystart = boatposy;
				var targety = ypos - randf_range(-500,-900)
				hook1.targety = targety
				add_child(hook1)
				hooksplaced += 1
				hook_time = 0
				
				for i in range(randi_range(3,6)):
					bait1 = bait.instantiate()
					bait1.position.x = xpos+randf_range(-150,150)
					bait1.position.y = player.position.y - 600
					bait1.targety = targety+randf_range(-50,50)
					add_child(bait1)
					
		for projectile in projectiles:
			manage_projectile(projectile, delta)
			
	for child in get_children():
		if child is Hook:
			#updates starting location of hook lines
			child.xstart = boatposx;
			child.ystart = boatposy;
			#print(abs(child.position.x-player.position.x))
			#frees hooks when out of range
			if abs(child.position.x-player.position.x)>1200:
				child.queue_free()
		if child is Bait:
			if abs(child.position.x-player.position.x)>1200:
				child.queue_free()
		
		if child is Player:
			#gets player position
			playerx = child.position.x
			#print(playerx)
			
		#gets boat position, sets boat velocity
		if child is Boat:
			boatposx = child.position.x
			boatposy = child.position.y
			child.vel = (playerx-child.position.x)/100
