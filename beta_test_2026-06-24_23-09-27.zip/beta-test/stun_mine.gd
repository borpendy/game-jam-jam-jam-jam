extends Area2D
class_name StunMine
@onready var hitbox = $CollisionShape2D
@onready var mine_sprite = $MineSprite
@onready var explosion_sprite = $ExplosionSprite
var time_passed: float = 0.0
const timer: float = 0.5
var blast_radius = 4
var effect_duration = 1
# Called every frame. 'delta' is the elapsed time since the previous frame.

func _ready():
	explosion_sprite.visible = false
	mine_sprite.visible = true
	hitbox.scale = Vector2(0, 0)

func expand_radius():
	hitbox.scale += Vector2(0.1, 0.1)
	
func _process(delta: float) -> void:
	time_passed += delta
	position.y += 5*60*(delta/1)
	
	if time_passed>timer:
		mine_sprite.visible = false
		explosion_sprite.visible = true
		explosion_sprite.play()
		expand_radius()
	
	if hitbox.scale >= Vector2(blast_radius, blast_radius):
		queue_free()
	pass


func _on_body_entered(body: Node2D) -> void:
	if body is Player:
		body.apply_state("stun", effect_duration)
