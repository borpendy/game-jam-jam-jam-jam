extends Area2D
class_name Bomb


var time_passed: float = 0.0
const timer: float = 2

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	time_passed += delta
	position.y += 5*60*(delta/1)
	if time_passed>timer:
		queue_free()
	pass
