extends Area2D
class_name Hook

var xstart = 0
var ystart = 0
var targety = 0
var hit = false

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.
	
func _draw() -> void:
	draw_line(to_local(Vector2(xstart,ystart)), (Vector2(0,0)), Color.GREEN, 4)



# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	#move hook if not hitting fish
	if hit == false:
		if (targety > -500):
			position = lerp(position, Vector2(position.x,targety), 0.01)
		else:
			position = lerp(position, Vector2(position.x,-500), 0.01)
	queue_redraw()

	
func _on_body_entered(body: Node2D) -> void:
	# chack if player
		if body is Player:
			hit = true
			if body.colliding == false:
				#single shot set properties
				body.colliding = true
				body.rotation = Vector2(body.position.x,body.position.y).angle_to_point(Vector2(position.x,position.y))-PI
				body.hookx = position.x
				body.hooky = position.y
				body.currenthook = self
				
				
func _exit_tree() -> void:
	get_parent().hooksplaced -= 1
