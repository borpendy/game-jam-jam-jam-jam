extends StaticBody2D
class_name Boat
var vel = 0;


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
#basic mover script
func _process(delta: float) -> void:
	position.x = position.x+vel
	
	
	pass
	
