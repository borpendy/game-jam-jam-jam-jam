extends Node2D

# Assumes body has a max_velocity attribute that it must obey
func add_velocity(body, velocity, max):
	if abs(body.velocity.x + velocity.x) < max.x:
		body.velocity.x += velocity.x

	if abs(body.velocity.y + velocity.y) < max.y:
		body.velocity.y += velocity.y
		
func add_friction(body, coef, max_vel):
	# Never mind this
	if body.velocity.x > max_vel.x:
		body.velocity.x -= 5 * coef
	elif body.velocity.x > 0:
		body.velocity.x -= coef
	elif body.velocity.x < -max_vel.x:
		body.velocity.x += 5 * coef
	elif body.velocity.x < 0:
		body.velocity.x += coef

	if body.velocity.y > max_vel.y:
		body.velocity.y -= 5 * coef
	elif body.velocity.y > 0:
		body.velocity.y -= coef
	elif body.velocity.y < -max_vel.y:
		body.velocity.y += 5 * coef
	elif body.velocity.y < 0:
		body.velocity.y += coef
		
func set_velocity(body, velocity, max):
	if abs(velocity) < max.x:
		body.velocity.x = velocity

	if abs(velocity) < max.y:
		body.velocity.y = velocity
