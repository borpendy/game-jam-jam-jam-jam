extends Node2D
@onready var pointer: Sprite2D = $Pointer

var sc = 2
var basesize := Vector2(32*sc, 160*sc)


var rect_size_orig := Vector2(32*sc, 32*sc)
var yset := Vector2(0, 64*sc)
var xset := Vector2(0, 32*sc)

var rectstart = Vector2(300,-150)


var rectposition
var targetposition

var barthickness = 0.5


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.
	
	
	

func _draw() -> void:
	#random values for generating target bar
	var yoffset = round(yset*randf_range(-1,1))
	#var xoffset = round(xset*randf_range(0,1))
	var xoffset = round(xset*barthickness)
	var rect_size = round(rect_size_orig-xoffset)
	
	rectposition = Rect2(-(basesize / 2)+rectstart,basesize)
	targetposition = Rect2(-(rect_size / 2)-yoffset+rectstart,rect_size)
	
	#draw main bar, target bar
	draw_rect(rectposition,Color.BLUE,true)
	draw_rect(targetposition,Color.MEDIUM_PURPLE,true)

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	#fix rotation
	global_rotation = 0
	
	if pointer.catchprogress >= 2000:
		#set escape event
		get_parent().status = 1
		queue_free()
		
		
	if pointer.catchprogress <= 0:
		#set catch event
		get_parent().status = 2
		queue_free()
		
	
	pass
	
func _input(event):
	pass
	
