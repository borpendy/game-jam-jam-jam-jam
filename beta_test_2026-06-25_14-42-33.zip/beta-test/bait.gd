extends Area2D
class_name Bait
var targety = 0

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	if (targety > -500):
		position = lerp(position, Vector2(position.x,targety), 0.01)
	else:
		position = lerp(position, Vector2(position.x,-500), 0.01)
	pass

func _on_body_entered(body: Node2D) -> void:
	# chack if player
	if body is Player:
		print("hit")
		body.mass += 2
		queue_free()
			
