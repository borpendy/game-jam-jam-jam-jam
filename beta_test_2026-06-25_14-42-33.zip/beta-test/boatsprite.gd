extends Sprite2D
@onready var sprite_2d: Sprite2D = $Sprite2D
var ypoint


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	ypoint = to_global(sprite_2d.position).y
	print(ypoint)
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	sprite_2d.position.y = to_local(Vector2(position.x,ypoint)).y
	pass
