extends Area2D
class_name Bomb
@onready var images_2_: AnimatedSprite2D = $"Images(2)"
@onready var collision_shape_2d: CollisionShape2D = $CollisionShape2D


var time_passed: float = 0.0
var delay = 0
var timer_1: float = 0
var timer_2: float = 0

var triggered = false
var explode = false
var armed = false


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	#set up stuff
	collision_shape_2d.disabled = true
	delay = randf_range(0.3,2)
	position.x = position.x + randf_range(-300,300)
	#print(delay)
	timer_1 = delay
	timer_2 = delay+1
	
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	position.y += 5*60*(delta/1)
	#arm bomb when close to fish
	if (abs(position.y-get_parent().playery)<700):
		armed = true
	if armed:
		time_passed += delta
	
	
	#animation handling
	if time_passed>timer_2 and explode == false:
		explode = true
		collision_shape_2d.disabled = false
		images_2_.play("explosion")
		
	elif time_passed>timer_1 and triggered == false:
		images_2_.play("trigger")
		triggered = true



func _on_body_entered(body: Node2D) -> void:
	#damage
	if body is Player:
		body.take_damage(1)
		print(body.health)
	pass # Replace with function body.


func _on_images_2_animation_finished():
	queue_free()
