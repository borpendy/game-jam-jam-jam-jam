extends Area2D
class_name Taser
@onready var hitbox = $CollisionShape2D
@onready var taser_sprite: AnimatedSprite2D = $tasersprite

var time_passed: float = 0.0
const timer: float = 2
var effect_duration = 2
# Called every frame. 'delta' is the elapsed time since the previous frame.

func _ready():
	taser_sprite.visible = true
	taser_sprite.play()
	position.y += 150

func _process(delta: float) -> void:
	time_passed += delta
	position.y += 2*60*(delta/1)
	#position.x = get_parent().boatposx
	
	if time_passed>timer:
		queue_free()
	pass


func _on_body_entered(body: Node2D) -> void:
	if body is Player:
		body.apply_state("stun", effect_duration)
