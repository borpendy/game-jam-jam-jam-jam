extends Area2D
class_name StunMine
@onready var hitbox = $CollisionShape2D
@onready var minesprite: AnimatedSprite2D = $Minesprite
var time_passed: float = 0.0
var timer_1: float = 2
var timer_2: float = 3
var blast_radius = 4
var effect_duration = 1
var armed = false
var delay

var triggered = false
var explode = false
# Called every frame. 'delta' is the elapsed time since the previous frame.

func _ready():
	hitbox.disabled = true
	delay = randf_range(0.3,2)
	position.x = position.x + randf_range(-300,300)
	#print(delay)
	timer_1 = delay
	timer_2 = delay+1

func _process(delta: float) -> void:
	
	if (abs(position.y-get_parent().playery)<700):
		armed = true
	if armed:
		time_passed += delta
		
	position.y += 5*60*(delta/1)
	
	
	if time_passed>timer_2 and explode == false:
		explode = true
		hitbox.disabled = false
		minesprite.play("explode")
		
	elif time_passed>timer_1 and triggered == false:
		#minesprite.play("trigger")
		triggered = true




func _on_body_entered(body: Node2D) -> void:
	if body is Player:
		body.apply_state("stun", effect_duration)


func _on_minesprite_animation_finished() -> void:
	queue_free()
	pass # Replace with function body.
