extends Area2D
class_name Hook

var xstart = 0
var ystart = 0
var targety = 0
var hit = false
var reeled = false
var distance = 0
var framecount = 0

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.
	
func _draw() -> void:
	draw_line(to_local(Vector2(xstart,ystart)), (Vector2(0,0)), Color.GREEN, 4)



# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	#move hook if not hitting fish
	if hit == false:
		if (targety > -500):
			position = lerp(position, Vector2(position.x,targety), 0.01)
		else:
			position = lerp(position, Vector2(position.x,-500), 0.01)
		distance = abs(position - Vector2(get_parent().boatposx,get_parent().boatposy))
	elif reeled == true:
		pass
		#var direction = (position - Vector2(get_parent().boatposx,get_parent().boatposy)).normalized()
		#position = position - direction * 1 * distance/900
		position = lerp(position, Vector2(xstart,ystart), 0.002)
	queue_redraw()

	
func _on_body_entered(body: Node2D) -> void:
	# chack if player
		if body is Player:
			hit = true
			if body.colliding == false:
				reeled = true
				#single shot set properties
				body.colliding = true
				#body.animated_sprite_2d.rotation = Vector2(body.position.x,body.position.y).angle_to_point(Vector2(position.x,position.y))-PI
				body.hookx = position.x
				body.hooky = position.y
				body.currenthook = self
				
				
func _exit_tree() -> void:
	get_parent().hooksplaced -= 1
