extends Area2D
class_name Boat
var vel = 0
var limit = 3

var rodpoint = 0
var framecount = 0
var targety
var initialy


var globalp

@onready var rod: Node2D = $rodpoint
@onready var sprite_2d: Sprite2D = $boatsprite/Sprite2D
@onready var boatsprite: Sprite2D = $boatsprite

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	targety = position.y
	initialy = position.y
	globalp = to_global(boatsprite.position)
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
#basic mover script
func _process(delta: float) -> void:
	
	
	
	
	
	framecount += 1
	
	if vel > limit:
		vel = limit
	if vel < -limit:
		vel = -limit
	#print(vel)
	#move if fish not being caught
	if (position.x+vel >-2300 and position.x+vel < 2300 and get_parent().catchevent == false):
		position.x = position.x+vel
	rodpoint = to_global(rod.position)
	
	if (framecount%240 == 0):
		targety = initialy + randf_range(30,50)
	elif (framecount%120 == 0):
		targety = initialy + randf_range(-30,-50)
	
	position = lerp(position,Vector2(position.x,targety),0.005)

func _on_body_entered(body: Node2D) -> void:
	if body is Player:
		if body.mg == true:
			body.boatentered = true
			print("boatenteredente")
		
	
	pass
	

	
