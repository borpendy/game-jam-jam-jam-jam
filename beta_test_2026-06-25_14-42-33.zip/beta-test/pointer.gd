extends Sprite2D
@onready var minigame: Node2D = $".."
var newposy
@onready var pointer: Sprite2D = $"."
@onready var mg_bubbles: Sprite2D = $"../MgWater/MgBubbles"

var size
var velocity = 0
var acceleration = 0.01
var current = 0
var current_target = 0

var time_passed: float = 0.0
const TIME_INTERVAL: float = 1
var current_smooth = 30

var catchprogress = 0


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	
	current_target = randf_range(0.01,0.007)
	current_target = current_target*[-1, 1].pick_random() 
	
	size = pointer.get_rect().size * pointer.scale
	
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	#create new current
	time_passed += delta
	if time_passed >= TIME_INTERVAL:
		current_target = randf_range(0.01,0.001)
		current_target = current_target*[-1, 1].pick_random() 
		time_passed = 0
		
	
	current = current + (current_target-current)/current_smooth
	mg_bubbles.position.y += current/0.05
	
	print(current_target)
		
	if Input.is_action_pressed("left_clicked"):
		#move bar down
		velocity = velocity + acceleration
		
			
	if Input.is_action_pressed("right_clicked"):
		#move bar up
		velocity = velocity - acceleration
		
	if minigame.rectposition.has_point(Vector2(position.x, position.y + velocity + size.y/2)) and minigame.rectposition.has_point(Vector2(position.x, position.y + velocity - size.y/2)):
			#if pointer inside bar
			#print("in target")
			velocity = velocity + current
			position.y = position.y + velocity
	else:
		velocity = current
	
	#make sure sprite is never larger than bar
	if minigame.targetposition.has_point(Vector2(position.x, position.y-size.y/2+5)) and minigame.targetposition.has_point(Vector2(position.x, position.y+size.y/2-5)):
		#catch logic
		catchprogress += 5

	
	
	
	pass
