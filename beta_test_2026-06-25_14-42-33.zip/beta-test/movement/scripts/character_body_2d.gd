extends CharacterBody2D
class_name Player

@onready var input_manager = %InputManager
@onready var engine = %PhysicsEngine
@onready var printer = %DebugPrinter
@onready var stats = self.get_node("PlayerStats")
@onready var hitbox: CollisionShape2D = $Hitbox
@onready var animated_sprite_2d: AnimatedSprite2D = $AnimatedSprite2D




var minigame

const fishscene = preload("res://minigame.tscn")
var colliding = false
var mg = false
var onhook = false
var boatentered = false

var rot = 0
var hookx = 0
var hooky = 0
var reference = 0
var r_reference = 0

var health = 5
var escapes = 0
var status = 0
var g = 0

var currenthook

var actions = {
	"left_clicked": [on_left_click, on_left_click_released],
	"sprint_pressed": [on_sprint_pressed, on_sprint_released]
}

var accel
var max_vel
var min_vel
var mass
var initial_mass
var direction_vector
var friction_coefficient
var drift
var max_stamina
var stamina
var time_since_last_stamina
var stamina_recover_time
var stamina_regen
var using_stamina
var sprint_velboost
var sprint_accelboost
var mass_scale_ratio
var player_state
var state_duration
var state_time_elapsed

func initialise_variables():
	accel = stats.acceleration
	max_vel = stats.max_velocity
	min_vel = stats.min_velocity
	mass = stats.mass
	initial_mass = mass
	friction_coefficient = stats.friction_coefficient
	drift = stats.drift
	stamina = stats.stamina
	max_stamina = stamina
	stamina_recover_time = stats.stamina_recover_time
	stamina_regen = stats.stamina_regen
	time_since_last_stamina = -1
	using_stamina = false
	sprint_velboost = stats.sprint_velboost
	sprint_accelboost = stats.sprint_accelboost
	mass_scale_ratio = stats.mass_scale_ratio
	direction_vector = Vector2(0, 0)
	
	player_state = "neutral"
	state_duration = 0
	state_time_elapsed = 0
	
	
var direction = rotation_degrees
	
func _ready():
	#some stuff for hook minigame
	reference = animated_sprite_2d.size
	reference.y=0
	
	#get configs
	initialise_variables()
	for action in actions:
		input_manager.get_indexed(action).connect(actions[action][0])

func on_left_click(click_position: Vector2):
	#core movement
	var curr_position = position
	#printer.debug_print(name, "Current pos " + str(curr_position))
	if colliding == false:
		animated_sprite_2d.rotation = velocity.angle()+PI
		
		direction_vector = click_position - curr_position
		direction_vector = (direction_vector / (direction_vector.length())) * accel
	
	#used for sprite orientation
	direction = animated_sprite_2d.rotation_degrees

func on_left_click_released():
	#set no acceleration
	direction_vector = Vector2(0, 0)
	
func on_sprint_pressed():
	#printer.debug_print(name, "Current sprinting velocity: " + str(velocity))
	if stamina > 0:
		max_vel = stats.max_velocity * sprint_velboost
		accel = stats.acceleration * sprint_accelboost
		stamina -= 1
		time_since_last_stamina = 0
		using_stamina = true
	else:
		on_sprint_released()
	
func on_sprint_released():
	max_vel = stats.max_velocity
	using_stamina = false
	
func _input(event: InputEvent) -> void:
	for action in actions:
		if event.is_action_released(action):
			actions[action][1].call()

func adjust_stamina():
	#regenerate stamina after recovery time passes
	if not using_stamina:
		time_since_last_stamina += 1
	if time_since_last_stamina > stamina_recover_time:
		if not stamina + stamina_regen > max_stamina:
			stamina += stamina_regen
			

func adjust_scale():
	#adjust scale
	var scalar = 1 + (float(mass - initial_mass)/mass_scale_ratio)
	hitbox.scale = Vector2(scalar, scalar)
	animated_sprite_2d.scale = Vector2(scalar, scalar)
	#print(scalar)
	
func apply_gravity():
	engine.add_velocity(self, Vector2(0,9.8), max_vel)
	#print(scalar)


func apply_state(state, effect_duration):
	#printer.debug_print(name, state + " applied to player for " + str(effect_duration) + " ticks")
	#apply player state to player
	player_state = state
	state_duration = effect_duration
	state_time_elapsed = 0

	
func check_state(delta):
	if not player_state == "neutral":
		state_time_elapsed += delta
		#print(state_time_elapsed)
		
		# If you need a state to apply some effect every tick, otherwise should be defined by the node applying the state
		if player_state == "stun":
			max_vel = stats.max_velocity/3
			
		if state_time_elapsed > state_duration:
			#reset condition
			player_state = "neutral"
			state_time_elapsed = 0
			state_duration = 0
			max_vel = stats.max_velocity
			
		
func take_damage(damage) -> void:
	health -= damage
	animated_sprite_2d.play("damaged")
	await animated_sprite_2d.animation_finished
	animated_sprite_2d.play("default")


func _physics_process(delta: float) -> void:
	#if (rotation<0):
		#rotation = 360-rotation 
	# minigame handling
	#print(rotation)
	
	check_state(delta)
	adjust_stamina()
	adjust_scale()
	
	
	if(position.y<-675):
		apply_gravity()
	else:
		engine.add_velocity(self, direction_vector, max_vel)
		engine.add_friction(self, friction_coefficient, max_vel)

	
	if (direction >=90 and direction<=270) :
		animated_sprite_2d.flip_v = true
	else:
		animated_sprite_2d.flip_v = false
	#print(rotation_degrees)
	
	# minigame handling
	
	
	if colliding == true:
		engine.set_velocity(self,Vector2(0,0))
		
		if mg == false:
			#one shot instantiate minigame
			get_parent().catchevent = true
			mg = true
			minigame = fishscene.instantiate()
			add_child(minigame)
				
		
		if boatentered:
			if (minigame != null):
				minigame.caught = true
				boatentered = false
			
			
		if status == 1:
			#escape event - from minigame
			escapes += 1
			mg = false
			colliding = false
			get_parent().catchevent = false
			currenthook.queue_free()
			
			status = 0
			
		if status == 2:
			#catch event - from minigame
			take_damage(1)
			engine.set_velocity(self, Vector2(-400,-500))
			animated_sprite_2d.rotation = Vector2(-400,-500).angle()+PI
			mg = false
			colliding = false
			get_parent().catchevent = false
			currenthook.queue_free()
			status = 0
		
		#rotation of fish on hook
		r_reference = reference.rotated(animated_sprite_2d.rotation)
		position.x = currenthook.position.x+r_reference.x/2
		position.y = currenthook.position.y+r_reference.y/2
		if animated_sprite_2d.rotation < PI/2:
			animated_sprite_2d.rotation += 0.05
			#print(animated_sprite_2d.rotation)
			
			
		if animated_sprite_2d.rotation > PI/2 :
			#print(animated_sprite_2d.rotation)
			animated_sprite_2d.rotation -= 0.05
			
			
	#ui
	#label.global_rotation = 0
	#print(animated_sprite_2d.rotation)
	
		
			
	move_and_slide()
