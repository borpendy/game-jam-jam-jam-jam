extends Node2D
@onready var life_fish_5: AnimatedSprite2D = $LifeFish5
@onready var life_fish_4: AnimatedSprite2D = $LifeFish4
@onready var life_fish_3: AnimatedSprite2D = $LifeFish3
@onready var life_fish_2: AnimatedSprite2D = $LifeFish2
@onready var life_fish: AnimatedSprite2D = $LifeFish
var hearts = [life_fish,life_fish_2,life_fish_3,life_fish_4,life_fish_5]
var health


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:

	match health:
		4:
			life_fish_5.play("dead")
		3:
			life_fish_4.play("dead")
		2:
			life_fish_3.play("dead")
		1:
			life_fish_2.play("dead")
		0:
			life_fish.play("dead")
			
	pass
	
	
