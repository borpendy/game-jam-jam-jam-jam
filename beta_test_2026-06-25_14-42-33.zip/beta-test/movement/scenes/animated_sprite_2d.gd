extends AnimatedSprite2D


var size = 0

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	# gets the size of the fish sprite in pixels
	size = sprite_frames.get_frame_texture("default", 1).get_size()
	print(size)
	
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass
