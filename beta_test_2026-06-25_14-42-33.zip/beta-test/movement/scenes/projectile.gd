extends Node2D

const projectile = preload("res://projectile.tscn")
var scene
var time
var interval
var enable

func create(scene, time, interval, enable):
	var new_projectile = projectile.instantiate()
	new_projectile.scene = scene
	new_projectile.time = time
	new_projectile.interval = interval
	new_projectile.enable = enable
	
	return new_projectile
